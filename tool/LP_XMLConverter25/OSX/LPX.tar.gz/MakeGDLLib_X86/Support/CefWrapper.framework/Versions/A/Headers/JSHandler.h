#import <Cocoa/Cocoa.h>

@class CefJSArray;
@class CefJSFunction;
@class CefJSObject;

#ifdef __cplusplus

template <class T>
class scoped_refptr;

class CefV8Value;
class CefV8Handler;
#endif

@interface CefJSValue : NSObject <NSCoding>
{
	NSNumber* number;
	NSString* string;
	CefJSArray* cefJSArray;
	CefJSFunction* cefJSFunction;
	CefJSObject* cefJSObject;

	bool undefined;
}

+(id) valueWithObject:(CefJSObject*)object;
+(id) valueWithArray:(CefJSArray*)array;
+(id) valueWithFunction:(CefJSFunction*)function;
+(id) valueWithBoolValue:(bool)boolValue;
+(id) valueWithIntValue:(NSInteger)intValue;
+(id) valueWithUIntValue:(NSUInteger)uintValue;
+(id) valueWithDoubleValue:(double)doubleValue;
+(id) valueWithStringValue:(NSString*)stringValue;
+(id) valueWithUndefined;
+(id) valueWithNull;

- (NSNumber*) getNumber;
- (NSString*) getString;
- (CefJSArray*) getCefJSArray;
- (CefJSFunction*) getCefJSFunction;
- (CefJSObject*) getCefJSObject;

- (bool) isNull;
- (bool) isUndefined;

-(scoped_refptr<CefV8Value>) getCefValueForHandler:(CefV8Handler*)handler;

@end

@interface CefJSArray : NSObject
{
	NSMutableArray<CefJSValue*>* values;
}

+(id) arrayWithArray:(NSMutableArray*)array;

-(NSArray*) getValues;
-(scoped_refptr<CefV8Value>) getCefValueForHandler:(CefV8Handler*)handler;

@end

@interface CefJSFunction : NSObject <NSCoding>
{
	NSString* name;
}

+(id) functionWithName:(NSString*)name;

-(NSString*) getName;
-(scoped_refptr<CefV8Value>) getCefValueForHandler:(CefV8Handler*)handler;

@end

@interface CefJSObject : NSObject <NSCoding>
{
	NSMutableDictionary<NSString*, CefJSValue*>* elements;
	
	NSString* name;
	bool asynch;
}

+ (id) objectWithName:(NSString*)name;
+ (id) objectWithName:(NSString*)name elements:(NSMutableDictionary<NSString*, CefJSValue*>*)elementsIn;

- (void) setAsynch:(bool)asynch;

- (NSMutableDictionary<NSString*, CefJSValue*>*) getElements;

- (bool) isAsynch;
- (NSString*) getName;
- (scoped_refptr<CefV8Value>) getCefValueForHandler:(CefV8Handler*)handler;

@end
