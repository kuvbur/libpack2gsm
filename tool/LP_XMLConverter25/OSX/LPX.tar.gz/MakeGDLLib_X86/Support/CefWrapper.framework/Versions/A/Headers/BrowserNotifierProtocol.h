#import <Cocoa/Cocoa.h>

@class CefJSValue;

@protocol BrowserNotifierDelegate

- (void)urlChanged:(NSString*)url;
- (CefJSValue*)jsCalledWithName:(NSString*)name parameters:(NSArray*)parameters;
- (void)heightChanged:(NSNumber*)height;
- (NSNumber*)urlWillChange:(NSString*)url;
- (void)pageSourceVisited:(NSString*)pageSource url:(NSString*)url;
- (void)onLoadingStateChange:(NSArray*) arr;
- (bool)beforeDownload:(NSArray*) arr;
- (bool)onDownloading:(NSArray*) arr;
- (void)onFinalFind:(NSNumber*)count ordinal:(NSNumber*)activeMatchOrdinal;
- (NSNumber*)onPreKeyEvent:(NSArray*)parameters;

@end
