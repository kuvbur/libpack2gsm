#import <Foundation/Foundation.h>

@interface AdvancedThreadPump : NSObject

- (void) start;
- (void) stop;

@end

@interface CefController : NSObject

+ (AdvancedThreadPump*) getThreadPump:(BOOL)destroy;

+ (void) initWithCachePath:(NSString*)cachePath language:(NSString*)language debugPort:(NSInteger)portNumber;
+ (void) quit;

@end
