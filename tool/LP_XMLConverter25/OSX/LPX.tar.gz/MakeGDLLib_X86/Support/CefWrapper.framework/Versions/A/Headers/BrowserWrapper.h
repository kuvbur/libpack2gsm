#import <Cocoa/Cocoa.h>

@class CefJSObject;

@class BrowserWrapperHelper;

@interface BrowserWrapper : NSObject
{
	BrowserWrapperHelper* helper;
	NSView* parentView;
	id delegate;
}

- (id) initWithView:(NSView*)view url:(NSString*)url delegate:(id)delegate;
- (void) setUrl:(NSString*)url;
- (void) setHtmlStr:(NSString*)html;
- (void) goBack;
- (void) goForward;
- (void) reload;
- (void) reloadIgnoreCache;
- (void) deleteCookiesOnUrl:(NSString*)url withName:(NSString*)cookieName;
- (void) print;
- (void) setContextMenuDisabled:(BOOL) disabled;
- (int) findStart:(int)sessionId searchString:(NSString*)searchString forward:(BOOL)forward matchCase:(BOOL)matchCase;
- (int) findNext:(int)sessionId forward:(BOOL)forward;
- (void) findStop;
- (BOOL) isBrowserInited;
- (void) enableContentHeightChangedEvent:(BOOL)enable;
- (void) setScrollBarVisibility:(BOOL)visible;

- (bool) registerAsynchJSObject:(CefJSObject*)jsObject;
- (bool) registerSynchJSObject:(CefJSObject*)JSObject;
- (bool) executeJS:(NSString*)jsCode;

- (void) doCopy;
- (void) cut;
- (void) paste;
- (void) undo;
- (void) redo;
- (void) selectAll;


@end
