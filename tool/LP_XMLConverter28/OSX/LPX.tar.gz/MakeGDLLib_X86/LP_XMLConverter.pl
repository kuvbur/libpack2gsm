#! /usr/bin/perl
use FindBin ;
use File::Spec::Functions;

my $makeGDLLibTool = catfile ($FindBin::Bin, "LP_XMLConverter.app", "Contents", "MacOS", "LP_XMLConverter") ;
exec $makeGDLLibTool, @ARGV ;

#	my $makecommand = shift (@ARGV);
#	if ($makecommand eq "createcontainer" || $makecommand eq "extractcontainer") {
#		exec $makeGDLLibTool, $makecommand, @ARGV ;
#	} else {
#		exec $makeGDLLibTool, $makecommand, "-toplatform", "MAC_INTEL", @ARGV ;
#	}
